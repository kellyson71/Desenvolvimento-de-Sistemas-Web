def processar_texto(texto):
    vogais = "aeiouAEIOUãõáéíóúâêîôû"
    qtd_vogais = sum(1 for c in texto if c in vogais)
    
    invertido = texto[::-1]
    
    limpo = texto.replace(" ", "").lower()
    is_palindromo = limpo == limpo[::-1]
    
    return qtd_vogais, invertido, is_palindromo

texto = "A cara rajada da jararaca"
v, inv, pal = processar_texto(texto)
print(f"Texto: {texto}\nVogais: {v}\nInvertido: {inv}\nÉ palíndromo? {pal}")
